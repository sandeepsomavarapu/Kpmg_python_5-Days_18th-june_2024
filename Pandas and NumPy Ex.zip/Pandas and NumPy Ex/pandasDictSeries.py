import pandas as pd
emps={
    'empid':123,
    'empname':'suresh',
    'empsal':23000
}
mydict=pd.Series(emps)
print(mydict)