import pandas as pd

print(pd.__version__)

#Series :column in a table 
a=[1,2,3]
myvar=pd.Series(a)
print(myvar)
# Lables
a1=[1,2,3]
myvar1=pd.Series(a1,index=['x','y','z'])
print(myvar1)
print(myvar1['y'])