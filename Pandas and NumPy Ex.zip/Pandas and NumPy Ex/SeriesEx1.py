import pandas as pd
import numpy as np

series=pd.Series()
print(series)
values=np.array(['s','a','n','d','e','e','p'])
ser=pd.Series(values)
print(ser)

df=pd.DataFrame()
print(df)
list=["accenture","kpmg","wipro","dell"]
df1=pd.DataFrame(list)
print(df1)

#Series.map





