# get_doc_info.py
from PyPDF2 import PdfReader
def get_info(path):
    with open(path, 'rb') as f:
        pdf = PdfReader(f)
        info = pdf.metadata
        number_of_pages = pdf.len
        print(info)
        author = info.author
        creator = info.creator
        producer = info.producer
        subject = info.subject
        title = info.title
if __name__ == '__main__':
    path = 'pythonoutline.pdf'
    get_info(path)