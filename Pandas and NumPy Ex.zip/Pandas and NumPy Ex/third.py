import numpy as np
arr=np.array([12,23,32,33])
print(arr.dtype)
arr1=np.array(["suresh","usha","manoj","rajesh"])
print(arr1.dtype)
arr2=np.array([1.3,2.3,9.2,2.1])
print(arr2.dtype)
#Functions 
arr3=np.array([12,22,31,42,53])
x=arr3.view()
arr3[0]=112

print(arr3)
print(x)