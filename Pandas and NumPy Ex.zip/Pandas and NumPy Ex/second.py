import numpy as np

ndarr=np.array(78)# 0-D array
print(ndarr)
ndarr1=np.array([11,12,13,14,15,16])#1-D Array
print(ndarr1[0:4])
print(ndarr1)
print(ndarr1.ndim)
print(ndarr1[0])
print(type(ndarr))
ndarr2=np.array([[11,12,13],[14,15,16]])#2-D Array
print(ndarr2)
print(ndarr2[0,-1])
print(ndarr2.ndim)
