import numpy as np
arr=np.array([[22,33,44,55],[11,22,33,44]])
print(arr.shape)

arr1=np.array([1,2,3,4,5,6,7,8,9,10,11,12])#1-d
newarr=arr1.reshape(4,3)#2-d
print(newarr)

arr2=np.array([1,2,3,4,5,6,7,8,9,10,11,12])#1-d
newarr1=arr2.reshape(2,3,2)#3-d
print(newarr1)