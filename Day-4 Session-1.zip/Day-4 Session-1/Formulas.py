from openpyxl.utils import FORMULAE
import openpyxl  
wb = openpyxl.load_workbook('marks.xlsx')  
sheet = wb.active 
sheet["B9"] = "=SUM(B2:B8)"
sheet["B10"] = "=AVERAGE(B2:B8)"
sheet["B11"] = "=MAX(B2:B8)"
wb.save(filename="marks.xlsx")