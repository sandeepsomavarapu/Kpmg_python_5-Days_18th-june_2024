package com.rps.employeemanagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.rps.employeemanagement.dao.EmployeeDAOI;
import com.rps.employeemanagement.entity.Employee;
import com.rps.employeemanagement.service.EmployeeService;

@SpringBootTest
class EmployeeCrudUsingDaoImplementationApplicationTests {
//		@Autowired
//		EmployeeServiceI service;
	@MockBean
	private EmployeeDAOI empRepository;

	@Autowired
	private EmployeeService empService;

//	@Test
//	public void testAddEmployee() {
//		Employee emp = new Employee(123,"mahesh",12312,949494,"capgemini");
//
//		String message = service.EmployeeCreation(emp);
//		assertEquals("Employee created successfully", message);
//	}

//	@Test
//	public void testGetEmployeeById() {
//
//		Employee emp = service.getEmployeeById(123);
//		
//		assertEquals("mahesh", emp.getName());
//
//	}
//	@Test
//	public void testAddEmployee() {
//		Employee emp = new Employee(123, "mahesh", 12312, 949494, "capgemini");
//		when(empRepository.EmployeeCreation(emp)).thenReturn("Employee Created Successfully");
//		String message = empService.EmployeeCreation(emp);
//
//		assertEquals("Employee Created Successfully", message);
//	}

	@Test
	public void testGetEmployeeById() {
		Employee emp = new Employee(123, "mahesh", 12312, 949494, "capgemini");
		when(empRepository.getEmployeeById(123)).thenReturn(emp);
		Employee emp1 = empService.getEmployeeById(123);
		assertEquals("mahesh", emp1.getName());

	}
}
