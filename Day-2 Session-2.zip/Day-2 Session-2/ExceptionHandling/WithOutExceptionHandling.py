num=int(input("Enter Denominator for division : "))#0
try:
    result = 12 /num #PVM
    print("Result is", result)#error code/risky code 
except ZeroDivisionError :
    print("Dont Enter zero as denominator")
print("Remaining 1000 lines of code")
#try except finally raise


#system defined error messages
#abnormal termination


#normal ternimation
#user friendly error message 












