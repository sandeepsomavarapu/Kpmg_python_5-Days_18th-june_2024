a=123
b="sandeep"
z=a+b