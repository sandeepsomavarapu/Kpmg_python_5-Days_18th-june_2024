price=10000
if(price<20000)
    print("Valid Price")