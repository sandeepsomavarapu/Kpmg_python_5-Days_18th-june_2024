import re

matcher=re.finditer("a?","abaabaaab") 
for match in matcher:
    print(match.start(),"...",match.group())# gmail.com  kpmg.co.in   sandeep@gmail.com sandeep14@gmail.com