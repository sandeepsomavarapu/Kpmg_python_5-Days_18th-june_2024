
import mysql.connector as conn

mydb=conn.connect(host="localhost",user="root",passwd="rpsconsulting",database="kpmg")

mycursor=mydb.cursor()

mycursor.execute("update studs set sname='sandeep' where stuid=127");

mydb.commit();