class Employee: #parent class
    x = 10 
    def __init__(self,eid):
        print("am from default constructor",eid)
    def display(self):
         print('Welcome to Employee Class')
 
class Department(Employee): #child class Department inherits Employee
    a = 250
    def __init__(self,eid):
        super().__init__(eid)
        print("am from default constructor")
    def func_message(self):
        print('Welcome to Department Class')
        print('This class is inherited from Employee')
emp = Employee(111)  #creating object for EMployee PVM
print(emp.x)       #calling parent class variable
emp.display()      #calling parent class function 

print('******************')
dept = Department(123)  #creating Object for Department
print(dept.a)         #calling child class variable
dept.func_message()    #calling child class function
print('*****************')
dept.display()   #calling parent class method using child Object
print(dept.x)  # calling & printing parent class variable using child Object   