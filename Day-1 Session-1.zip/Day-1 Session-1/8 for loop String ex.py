# Python For Loop - String Example
Str = "Python"
for word in range(len(Str)):
    print("Letters at index {0} is = {1}".format(word, Str[word]))
  
print("----This is Outside String For Loop---")
print(" ")

# Python For Loop - List Example
Countries = ['India', 'U K', 'U S A', 'Australia']
for Country in range(len(Countries)):
	
	print("Countries at index {0} is = {1}".format(Country,Countries[Country]))
